// backend/models/Order.js
const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
  customerName: { type: String, required: true },
  customerEmail: { type: String, required: true },
  items: [
    {
      name: String,
      price: Number
    }
  ],
  total: Number,
  // you can keep 'date' if you want, but timestamps will add createdAt automatically
  date: { type: Date, default: Date.now }
}, { timestamps: true }); // <-- enable createdAt / updatedAt

module.exports = mongoose.model('Order', orderSchema);
