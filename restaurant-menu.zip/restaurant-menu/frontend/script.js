// ===================== MENU DATA =====================
const menuItems = [
  { id: 1, name: 'Cheese Burger', price: 150, category: 'burgers', img: 'https://cdn.pixabay.com/photo/2014/10/23/18/05/burger-500054_1280.jpg' },
  { id: 2, name: 'Chicken Burger', price: 180, category: 'burgers', img: 'https://www.recipetineats.com/wp-content/uploads/2017/07/Chicken-Burgers-4.jpg' },
  { id: 3, name: 'Veggie Burger', price: 130, category: 'burgers', img: 'https://bing.com/th?id=OSK.6641dfff33105948a1b82a641b550c80' },
  { id: 4, name: 'Margherita Pizza', price: 200, category: 'pizzas', img: 'https://th.bing.com/th/id/OIP.khPwxHGxDlj1zHBQwMBnXAHaLJ?w=208&h=305&c=7&r=0&o=7&cb=12&dpr=1.3&pid=1.7&rm=3' },
  { id: 5, name: 'Pepperoni Pizza', price: 250, category: 'pizzas', img: 'https://www.simplyrecipes.com/thmb/rLl58QZmVP4C3zSlpkKBo72EUws=/2000x1333/filters:fill(auto,1)/__opt__aboutcom__coeus__resources__content_migration__simply_recipes__uploads__2019__09__easy-pepperoni-pizza-lead-3-8f256746d649404baa36a44d271329bc.jpg' },
  { id: 6, name: 'Veggie Supreme Pizza', price: 270, category: 'pizzas', img: 'https://i0.wp.com/www.thursdaynightpizza.com/wp-content/uploads/2022/06/veggie-pizza-side-view-out-of-oven.png?resize=720%2C480&is-pending-load=1#038;ssl=1' },
  { id: 7, name: 'Chicken Biryani', price: 300, category: 'maincourse', img: 'https://th.bing.com/th/id/OIP.niF8N9Z3Hl8u7-rC6c5rHQHaHa?w=192&h=192&c=7&r=0&o=7&cb=12&dpr=1.3&pid=1.7&rm=3' },
  { id: 8, name: 'Paneer Butter Masala', price: 280, category: 'maincourse', img: 'https://www.vegrecipesofindia.com/wp-content/uploads/2020/01/paneer-butter-masala-4.jpg' },
  { id: 9, name: 'Fried Rice', price: 200, category: 'maincourse', img: 'https://tse3.mm.bing.net/th/id/OIP.gpD8wC7-RpOqR1_eqtf4FQHaE8?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3' },
  { id: 10, name: 'Cold Coffee', price: 120, category: 'drinks', img: 'https://rachnas-kitchen.com/wp-content/uploads/2017/07/cold-coffee-2.jpg' },
  { id: 11, name: 'Mango Juice', price: 100, category: 'drinks', img: 'https://loseweightbyeating.com/wp-content/uploads/2022/06/AdobeStock_187649791-267x400.jpeg' },
  { id: 12, name: 'Lemon Soda', price: 90, category: 'drinks', img: 'https://tse2.mm.bing.net/th/id/OIP.ZDOAMgpiw6PqAhxIh9XwJwHaLH?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3' },
  { id: 13, name: 'Chocolate Cake', price: 180, category: 'desserts', img: 'https://charlotteslivelykitchen.com/wp-content/uploads/2019/01/chocolate-cake-3.jpg' },
  { id: 14, name: 'Ice Cream Sundae', price: 160, category: 'desserts', img: 'https://www.chocolatemoosey.com/wp-content/uploads/2016/04/Fried-Ice-Cream-Sundaes-3219.jpg' },
  { id: 15, name: 'Donut', price: 90, category: 'desserts', img: 'https://tse2.mm.bing.net/th/id/OIP.AfgAxoXXDcvMVLpPqrsEIwHaF7?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3' }
];

// ===================== VARIABLES =====================
let cart = [];

// ===================== DISPLAY MENU =====================
function displayMenu(items) {
  const container = document.getElementById("menuContainer");
  container.innerHTML = "";
  items.forEach(item => {
    const card = document.createElement("div");
    card.classList.add("menu-item");
    card.innerHTML = `
      <img src="${item.img}" alt="${item.name}">
      <h3>${item.name}</h3>
      <p>₹${item.price}</p>
      <button onclick="addToCart(${item.id})">Add to Cart</button>
    `;
    container.appendChild(card);
  });
}

// ===================== FILTER & SEARCH =====================
document.getElementById("categoryFilter").addEventListener("change", e => {
  const category = e.target.value;
  displayMenu(category === "all" ? menuItems : menuItems.filter(item => item.category === category));
});

document.getElementById("searchBox").addEventListener("input", e => {
  const searchTerm = e.target.value.toLowerCase();
  displayMenu(menuItems.filter(item => item.name.toLowerCase().includes(searchTerm)));
});

// ===================== CART FUNCTIONS =====================
function addToCart(id) {
  const item = menuItems.find(i => i.id === id);
  cart.push(item);
  updateCartDisplay();
}

function updateCartDisplay() {
  const orderDetails = document.getElementById("orderDetails");
  const totalPrice = document.getElementById("totalPrice");
  orderDetails.innerHTML = "";
  let total = 0;

  cart.forEach((item, index) => {
    total += item.price;
    orderDetails.innerHTML += `
      <div class="cart-item">
        ${item.name} - ₹${item.price}
        <button class="removeBtn" onclick="removeItem(${index})">x</button>
      </div>`;
  });

  totalPrice.textContent = total;
}

function removeItem(index) {
  cart.splice(index, 1);
  updateCartDisplay();
}

// ===================== PLACE ORDER =====================
document.getElementById("placeOrderBtn").addEventListener("click", () => {
  if (cart.length === 0) return alert("🛒 Your cart is empty!");

  const name = prompt("Enter your name:");
  const email = prompt("Enter your email:");

  if (!name || !email) return alert("Please provide your name and email to confirm your order.");

  const orderData = {
    customerName: name,
    customerEmail: email,
    items: cart,
    total: cart.reduce((sum, i) => sum + i.price, 0),
    date: new Date().toISOString() // <-- safe ISO date
  };

  saveOrderToBackend(orderData);
  cart = [];
  updateCartDisplay();
});

// ===================== SAVE ORDER TO BACKEND =====================
function saveOrderToBackend(orderData) {
  fetch("http://localhost:5000/api/orders", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(orderData)
  })
    .then(res => res.json())
    .then(data => {
      alert("✅ Order placed successfully!");
      loadOrderHistory(); // reload history
    })
    .catch(err => console.error("Error saving order:", err));
}

// ===================== FORMAT DATE =====================
function formatDate(isoString) {
  if (!isoString) return "—";
  const d = new Date(isoString);
  return isNaN(d) ? isoString : d.toLocaleString();
}

// ===================== LOAD ORDER HISTORY =====================
function loadOrderHistory() {
  fetch("http://localhost:5000/api/orders")
    .then(res => res.json())
    .then(data => {
      const container = document.getElementById("orderHistoryContainer");
      container.innerHTML = "";

      if (!data.length) {
        container.innerHTML = "<p>No past orders found.</p>";
        return;
      }

      data.reverse().forEach(order => {
        const orderDiv = document.createElement("div");
        orderDiv.classList.add("order-history-card");
        const date = formatDate(order.createdAt || order.date);
        orderDiv.innerHTML = `
          <h3>Order #${order._id ? order._id.slice(-5) : '—'}</h3>
          <p><strong>Name:</strong> ${order.customerName}</p>
          <p><strong>Email:</strong> ${order.customerEmail}</p>
          <p><strong>Date:</strong> ${date}</p>
          <p><strong>Total:</strong> ₹${order.total}</p>
          <ul>${order.items.map(i => `<li>${i.name} - ₹${i.price}</li>`).join("")}</ul>
        `;
        container.appendChild(orderDiv);
      });
    })
    .catch(err => console.error("Error loading order history:", err));
}

// ===================== INITIALIZE =====================
document.addEventListener("DOMContentLoaded", () => {
  displayMenu(menuItems);
  loadOrderHistory();
});


function deleteOrderHistory() {
  if (!confirm("⚠️ Are you sure you want to delete all order history?")) return;

  fetch("http://localhost:5000/api/orders", {
    method: "DELETE",
  })
    .then(res => res.json())
    .then(data => {
      alert("🗑️ All order history deleted!");
      loadOrderHistory(); // refresh history display
    })
    .catch(err => console.error("Error deleting history:", err));
}

